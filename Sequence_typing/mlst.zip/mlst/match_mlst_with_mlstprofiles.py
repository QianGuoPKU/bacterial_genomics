import pandas as pd
import numpy as np
import sys,os

def joinValues(df):
	return ','.join(df.astype('str'))

def match_oxford(fin, profile):
    # ST	gltA	gyrB	gdhB	recA	cpn60	gpi	rpoD	clonal_complex	species
    profile = pd.read_csv(profile, sep='\t', header=0)
    stdict = dict()
    for i in range(len(profile)):
        scheme = [str(x) for x in profile.values[i][1:8]]
        scheme = ','.join(scheme)
        stdict[scheme] = profile.values[i][0]
    outsamples = []
    outsts = []
    outgltas = []
    outgyrbs = []
    outgdhbs = []
    putrecas = []
    outcnp60s = []
    outgpis = []
    outrpods = []
    outnotes = []
    for line in fin.readlines():
        tmp = line.split('/')
        tmp = tmp[len(tmp)-1]
        outsamples.append(tmp.split('.', 1)[0])
        outgltas.append(line.split('Oxf_gltA(')[1].split(')', 1)[0])
        outgyrbs.append(line.split('Oxf_gyrB(')[1].split(')', 1)[0])
        outgdhbs.append(line.split('Oxf_gdhB(')[1].split(')', 1)[0])
        putrecas.append(line.split('Oxf_recA(')[1].split(')', 1)[0])
        outcnp60s.append(line.split('Oxf_cpn60(')[1].split(')', 1)[0])
        outgpis.append(line.split('Oxf_gpi(')[1].split(')', 1)[0])
        outrpods.append(line.split('Oxf_rpoD(')[1].split(')', 1)[0])
    outdict = {'sample': outsamples, 'gltA': outgltas, 'gyrB': outgyrbs, 'gdhB': outgdhbs, 'recA': putrecas,
               'cpn60': outcnp60s, 'gpi': outgpis, 'rpoD': outrpods}
    outdf = pd.DataFrame.from_dict(outdict)
    outdf = outdf.assign(gltA=outdf.gltA.str.split(',')).explode('gltA').reset_index(drop=True)
    outdf = outdf.assign(gyrB=outdf.gyrB.str.split(',')).explode('gyrB').reset_index(drop=True)
    outdf = outdf.assign(gdhB=outdf.gdhB.str.split(',')).explode('gdhB').reset_index(drop=True)
    outdf = outdf.assign(recA=outdf.recA.str.split(',')).explode('recA').reset_index(drop=True)
    outdf = outdf.assign(cpn60=outdf.cpn60.str.split(',')).explode('cpn60').reset_index(drop=True)
    outdf = outdf.assign(gpi=outdf.gpi.str.split(',')).explode('gpi').reset_index(drop=True)
    outdf = outdf.assign(rpoD=outdf.rpoD.str.split(',')).explode('rpoD').reset_index(drop=True)
    for i in range(len(outdf)):
        tmpscheme = [str(x) for x in outdf.values[i][1:8]]
        tmpscheme = ','.join(tmpscheme)
        if "?" in tmpscheme or '~' in tmpscheme:
            note = 'uncertain'

        else:
            note = 'certain'
        tmpscheme = tmpscheme.replace('?', '').replace('~', '')
        if tmpscheme in stdict.keys():
            st = stdict[tmpscheme]
        else:
            st = 'NAN'
        outsts.append(st)
        outnotes.append(note)
    outdf['ST'] = outsts
    outdf['note'] = outnotes
    return outdf


def match_pasteur(fin, profile):
    # Pas_cpn60 Pas_gltA	Pas_recA    Pas_fusA   Pas_pyrG		Pas_rplB	Pas_rpoB
    profile = pd.read_csv(profile, sep='\t', header=0)
    stdict = dict()
    for i in range(len(profile)):
        scheme = [str(x) for x in profile.values[i][1:8]]
        scheme = ','.join(scheme)
        stdict[scheme] = profile.values[i][0]
    outsamples = []
    outsts = []
    outgltas = []
    outcnp60s = []
    outrecas = []
    outfusas = []
    outpyrgs = []
    outrplbs = []
    outrpobs = []
    outnotes = []
    for line in fin.readlines():
        tmp = line.split('/')
        tmp = tmp[len(tmp) - 1]
        outsamples.append(tmp.split('.', 1)[0])
        outgltas.append(line.split('Pas_gltA(')[1].split(')', 1)[0])
        outcnp60s.append(line.split('Pas_cpn60(')[1].split(')', 1)[0])
        outrecas.append(line.split('Pas_recA(')[1].split(')', 1)[0])
        outfusas.append(line.split('Pas_fusA(')[1].split(')', 1)[0])
        outpyrgs.append(line.split('Pas_pyrG(')[1].split(')', 1)[0])
        outrplbs.append(line.split('Pas_rplB(')[1].split(')', 1)[0])
        outrpobs.append(line.split('Pas_rpoB(')[1].split(')', 1)[0])
    outdict = {'sample': outsamples, 'gltA': outgltas, 'cpn60': outcnp60s, 'recA': outrecas, 'fusA': outfusas,
               'pyrG': outpyrgs, 'rplB': outrplbs, 'rpoB': outrpobs}
    outdf = pd.DataFrame.from_dict(outdict)
    outdf = outdf.assign(gltA=outdf.gltA.str.split(',')).explode('gltA').reset_index(drop=True)
    outdf = outdf.assign(cpn60=outdf.cpn60.str.split(',')).explode('cpn60').reset_index(drop=True)
    outdf = outdf.assign(recA=outdf.recA.str.split(',')).explode('recA').reset_index(drop=True)
    outdf = outdf.assign(fusA=outdf.fusA.str.split(',')).explode('fusA').reset_index(drop=True)
    outdf = outdf.assign(pyrG=outdf.pyrG.str.split(',')).explode('pyrG').reset_index(drop=True)
    outdf = outdf.assign(rplB=outdf.rplB.str.split(',')).explode('rplB').reset_index(drop=True)
    outdf = outdf.assign(rpoB=outdf.rpoB.str.split(',')).explode('rpoB').reset_index(drop=True)
    for i in range(len(outdf)):
        tmpscheme = [str(x) for x in outdf.values[i][1:8]]
        tmpscheme = ','.join(tmpscheme)
        if "?" in tmpscheme or '~' in tmpscheme:
            note = 'uncertain'

        else:
            note = 'certain'
        tmpscheme = tmpscheme.replace('?', '').replace('~', '')
        if tmpscheme in stdict.keys():
            st = stdict[tmpscheme]
        else:
            st = 'NAN'
        outsts.append(st)
        outnotes.append(note)
    outdf['ST'] = outsts
    outdf['note'] = outnotes
    return outdf

if __name__ == '__main__':
    # add newfilename
    #"""
    profile = sys.argv[1]
    tablefile = sys.argv[2]
    outfile = sys.argv[3]
    fin = open(tablefile, 'r')

    # match Oxford MLST
    if "oxford" in profile:
        outdf = match_oxford(fin, profile)

    # match Pasteur MLST
    if "pasteur" in profile:
        outdf = match_pasteur(fin, profile)

    outdict = {'sample': outdf['sample'].tolist(), 'ST':outdf['ST'].tolist()}
    outdf = pd.DataFrame.from_dict(outdict)
    print(outdf)
    outdf = outdf.groupby(['sample'])['ST'].apply(list)
    outdf.to_csv(outfile, sep='\t')
    outdf = pd.read_csv(outfile, sep='\t', header=0)
    outdf['ST'] = [x.strip('[').strip(']').replace("'", '').replace(' ','') for x in outdf['ST'].tolist()]
    print(outdf)
    outdf.to_csv(outfile, sep='\t', index=False)

