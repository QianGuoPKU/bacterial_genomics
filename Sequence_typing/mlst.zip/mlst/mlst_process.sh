#mlst --scheme abaumannii_2 --threads 5 $1/*.fasta >$2/pasteur_mlst_result.txt
mlst --scheme abaumannii --threads 5 $1/*.fasta >$2/oxford_mlst_result.txt


