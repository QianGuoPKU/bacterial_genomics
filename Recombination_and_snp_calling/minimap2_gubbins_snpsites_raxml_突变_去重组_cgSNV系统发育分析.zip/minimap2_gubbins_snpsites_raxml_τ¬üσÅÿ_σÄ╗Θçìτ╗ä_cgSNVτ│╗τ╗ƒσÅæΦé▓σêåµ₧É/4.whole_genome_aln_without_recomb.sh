python /data2/qguo/software/gubbins-master/python/scripts/mask_gubbins_aln.py --aln ../2.gubbins/all.consensus.aln --gff ../2.gubbins/gubbins.recombination_predictions.gff --out wgs_align_without_recomb.aln



