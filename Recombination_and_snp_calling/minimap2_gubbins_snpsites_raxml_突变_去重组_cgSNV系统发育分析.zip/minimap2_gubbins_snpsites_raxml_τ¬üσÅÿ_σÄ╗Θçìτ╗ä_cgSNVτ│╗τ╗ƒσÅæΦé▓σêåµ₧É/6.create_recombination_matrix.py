import numpy as np
import pandas as pd
import sys, os
from tqdm import tqdm
#from collections import Counter


if __name__ == '__main__':
    wkdir = sys.argv[1]
    infile = sys.argv[2]
    outfile = sys.argv[3]

    metadatafile = '/data/qguo/projects/baoman/single/single_all/metadata/metadata-update.txt'
    metadata = pd.read_csv(metadatafile, sep = '\t', header=0, usecols=['sample', 'clone5', 'Oxford.ST'])

    features = []
    readflag = 0
    #recomb_df = pd.DataFrame()
    with open(infile, 'r') as fin:
        for l in fin.readlines():
            if "misc_feature" in l:
                readflag = 1
                feature = l.strip('').split()[2]
                features.append(feature)
                #print(feature)
    #"""
            if readflag & ("taxa" in l):
                samples = l.strip('').split('=')[1].strip().strip('"').split()
                #print(samples)
                tmpdf = pd.DataFrame({'sample':samples})
                tmpdf[feature] = 1
                metadata = pd.merge(metadata, tmpdf, on = 'sample', how='left')
                readflag = 0

    metadata.to_csv(outfile, sep = '\t', index=False)
    #"""






