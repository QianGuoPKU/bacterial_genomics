import sys, os
from Bio import SeqIO

if __name__ == '__main__':
    os.chdir('/data/qguo/projects/baoman/single/single_icu/annotation_on_scaffolds/workflow_from_NC/ref/3.recombination_gubbins/1.minimap2')
    fasta = 'ICU_ab_yangxianxing180719.consensus.fa'
    #fasta = '/data/qguo/projects/baoman/single/single_icu/annotation_on_scaffolds/workflow_from_NC/ref/outgroup_annotated/outgroup.fna'
    #fasta = '/data/qguo/projects/baoman/single/single_icu/annotation_on_scaffolds/workflow_from_NC/ref/NZ_CP018256.1.fasta'
    start = int(10406)
    end = int(10425)
    record = SeqIO.read(fasta, 'fasta')
    #print(record.seq)
    print(len(str(record.seq)))
    print(str(record.seq)[start:end])