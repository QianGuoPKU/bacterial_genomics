import sys, os
from Bio import SeqIO

if __name__ == '__main__':
    file = sys.argv[1]
    #output = sys.argv[2]
    name = sys.argv[2]
    record = SeqIO.read(file, 'fasta')
    record.id = name
    record.description = ''
    SeqIO.write(record, file, 'fasta')