# this script was run in snippy_qg env
for name in `cat $1`
do
echo $name
samtools view -S -b $2/$name'.sam' > $2/$name'_aln.bam'
samtools sort $2/$name'_aln.bam' -o $2/$name'_aln_sorted.bam'
bcftools mpileup -Ou -f /data/qguo/projects/baoman/single/single_all/ref/outgroup_annotated/outgroup_annotated.fna $2/$name'_aln_sorted.bam' | bcftools call -mv -Ov -o $2/$name'.vcf'
sed -i '/INDEL\;/d' $2/$name'.vcf'
bgzip $2/$name'.vcf' -c -f >$2/$name'.vcf.gz'
bcftools index $2/$name'.vcf.gz'
cat /data/qguo/projects/baoman/single/single_all/ref/outgroup_annotated/outgroup_annotated.fna | bcftools consensus $2/$name'.vcf.gz' > $2/$name'.consensus.fa'
python /data/qguo/projects/baoman/single/single_all/code/recombination/gubbins/rename_consensus.py $2/$name'.consensus.fa' $name
done
#cat $2/*consensus.fa > $3/all.consensus.aln
#cd $3
#run_gubbins.py -p gubbins -c 40 all.consensus.aln





