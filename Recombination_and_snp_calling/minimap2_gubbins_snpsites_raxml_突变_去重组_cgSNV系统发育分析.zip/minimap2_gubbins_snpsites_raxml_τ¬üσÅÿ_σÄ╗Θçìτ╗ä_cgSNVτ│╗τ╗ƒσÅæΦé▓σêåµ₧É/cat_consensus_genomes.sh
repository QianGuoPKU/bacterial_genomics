for name in `cat $1`
do
cat $2/$name'.consensus.fa' >> $3
done





