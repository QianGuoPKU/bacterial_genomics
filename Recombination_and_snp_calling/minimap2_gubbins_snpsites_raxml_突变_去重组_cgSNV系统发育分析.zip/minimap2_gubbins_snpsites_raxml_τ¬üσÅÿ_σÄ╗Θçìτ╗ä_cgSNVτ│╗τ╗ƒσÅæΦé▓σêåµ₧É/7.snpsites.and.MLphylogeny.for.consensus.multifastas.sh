snp-sites -c -v -m -o $2/clean.core.aln $1/all.consensus.aln

/data2/qguo/software/standard-RAxML-8.2.12/raxmlHPC-HYBRID -s $2/clean.core.aln.snp_sites.aln -w $3 -n abaumannii -m GTRGAMMA -T 50 -N 1000 -p 20170808 -f a -x 20170808




