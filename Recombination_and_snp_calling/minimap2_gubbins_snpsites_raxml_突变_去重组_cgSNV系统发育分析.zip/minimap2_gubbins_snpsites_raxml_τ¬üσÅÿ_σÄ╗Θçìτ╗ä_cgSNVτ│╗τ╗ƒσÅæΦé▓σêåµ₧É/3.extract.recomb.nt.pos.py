import pandas as pd
import sys,os
from tqdm import tqdm
import numpy as np

if __name__=='__main__':
    # infile : gubbins predicted recomb gff file
    ingfffile = sys.argv[1]
    outfile1 = sys.argv[2] # outfile1: recombination and position
    outfile2 = sys.argv[3] # outfile2: the length of each recombination fragment
    ingff = pd.read_csv(ingfffile, sep = '\t', skiprows=2, usecols=[3,4], header=None)
    ingff.columns = ['start', 'end']
    pos = []
    lens = []
    for i in tqdm(range(len(ingff))):
        start = ingff['start'][i]
        end = ingff['end'][i] + 1
        lens.extend([int(end - start)])
        pos.extend(list(range(start, end)))
    pos = np.unique(pos)
    outdf = pd.DataFrame({'position':pos, 'recomb':['recombination'] * len(pos)})
    outdf.to_csv(outfile1, sep = '\t', index=False)
    outdf = pd.DataFrame({'length':lens})
    outdf.to_csv(outfile2, sep='\t', index=False)

