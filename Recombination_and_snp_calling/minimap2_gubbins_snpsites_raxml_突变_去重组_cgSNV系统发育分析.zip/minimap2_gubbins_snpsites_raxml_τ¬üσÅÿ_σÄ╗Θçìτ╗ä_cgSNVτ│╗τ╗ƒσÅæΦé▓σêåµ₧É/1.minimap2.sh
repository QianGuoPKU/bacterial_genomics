# step1: minimap mapping contigs to ref genome
for name in `cat $1`
do
echo $name
minimap2 -ax asm20 -t 40 --eqx /data/qguo/projects/baoman/single/single_all/ref/outgroup_annotated/outgroup_annotated.fna $2/$name/$name'.fna' >$3/$name'.sam'
#  -o $3/$name'.aln'
done




