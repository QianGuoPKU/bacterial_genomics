import sys, os
from Bio import SeqIO
import pandas as pd
import numpy as np
import bioframe as bf
from collections import Counter

def combine_rows(df):
    vals = df.values
    vals = [x for x in vals if x != 'nan']
    return ','.join(vals)

if __name__ == '__main__':
    wkdir = sys.argv[1]
    os.chdir(wkdir)

    recombfile = 'gubbins.recombination_predictions.gff'
    reffile = '/data/qguo/projects/baoman/single/single_all/ref/outgroup_annotated/outgroup_annotated.gff'
    ref_annofile = '/data/qguo/projects/baoman/single/single_all/ref/outgroup_annotated/outgroup_pan_gene_pres_abs.txt'
    pan_annofile = '/data/qguo/projects/baoman/single/single_all/ref/major.lineage/roary/paralog_split_90id_100cd/pan_gene_anno/pan_gene_func_hgt_recomb_anno.txt'

    recomb = pd.read_csv(recombfile, sep = '\t', comment='#', header=None, usecols=[3,4])
    recomb.columns = ['start', 'end']
    recomb['chrom'] = 'chr1'

    os.system('sed -e "/##/d" ' + reffile + '> tmp')
    os.system('grep "gnl|Prokka" tmp >tmp.gff')
    os.system('sed -e "/>/d" tmp.gff > use.gff')
    os.system('rm -f tmp tmp.gff')
    ref = pd.read_csv('use.gff', sep=None, header=None, error_bad_lines=False)
    ref.columns = ['contig', 'source', 'type', 'start', 'end', 'score', 'strand', 'phase', 'attribute']
    ref = ref[ref['source'] != 'prokka']
    gff_sequences = [x.split(';', 1)[0].split('=')[1] for x in ref['attribute'].tolist()]
    ref['sequence'] = gff_sequences
    ref_region = ref[['start', 'end']]
    ref_region['chrom'] = 'chr1'

    overlapping_intervals = bf.overlap(recomb, ref_region, how='inner', suffixes=('_1','_2'))
    print(overlapping_intervals)
    print(len(overlapping_intervals))
    overlapping_intervals = overlapping_intervals[['start_2', 'end_2']]
    #
    overlapping_intervals['start_2'] = overlapping_intervals['start_2'].astype('str')
    overlapping_intervals['end_2'] = overlapping_intervals['end_2'].astype('str')
    overlapping_intervals['start_end'] = overlapping_intervals['start_2'] + '_' + overlapping_intervals['end_2']
    count_df = overlapping_intervals['start_end'].value_counts().to_frame()
    count_df.columns = ['recomb_frequence']
    count_df['start_end'] = list(count_df.index)

    overlapping_intervals = pd.merge(overlapping_intervals, count_df, on='start_end', how='left')
    overlapping_intervals = overlapping_intervals.drop_duplicates()
    print(overlapping_intervals)
    overlapping_intervals['recomb'] = 'recombination'
    #"""

    ref['start'] = ref['start'].astype('str')
    ref['end'] = ref['end'].astype('str')
    recomb_locus = pd.merge(ref, overlapping_intervals, left_on=['start', 'end'], right_on=['start_2', 'end_2'], how='left')
    recomb_locus = recomb_locus[['sequence', 'recomb', 'recomb_frequence', 'start', 'end']]

    ref_anno = pd.read_csv(ref_annofile, sep = '\t', header=0)
    outdf = pd.merge(ref_anno, recomb_locus, left_on='Gene', right_on='sequence', how='outer')
    print(outdf)

    pan_anno = pd.read_csv(pan_annofile, sep = '\t', header=0, usecols=['ref_id', 'Tn_com', 'phage_com', 'plasmid_com', 'island_com'])
    pan_anno = pan_anno.fillna('NaN')

    tn = pan_anno.groupby(['ref_id'])['Tn_com'].apply(combine_rows).reset_index()
    #print(pan_anno)
    phage = pan_anno.groupby(['ref_id'])['phage_com'].apply(combine_rows).reset_index()
    plasmid = pan_anno.groupby(['ref_id'])['plasmid_com'].apply(combine_rows).reset_index()
    island = pan_anno.groupby(['ref_id'])['island_com'].apply(combine_rows).reset_index()
    pan_anno = pd.merge(tn, phage, how='outer')
    pan_anno = pd.merge(pan_anno, plasmid, how='outer')
    pan_anno = pd.merge(pan_anno, island, how='outer')
    print(pan_anno)
    pan_anno = pan_anno.drop_duplicates(subset=['ref_id'], keep='first')
    outdf = pd.merge(outdf, pan_anno, left_on='Gene', right_on='ref_id', how='left')
    print(outdf)

    outdf = outdf.drop(['sequence'],1)
    outdf.to_csv('recombination_anno_0313.txt', sep = '\t', index=False)
    #"""




    """
    ref_interval = pd.IntervalIndex.from_arrays(ref_region.start, ref_region.end, closed='both')
    recomb_interval = pd.IntervalIndex.from_arrays(recomb.start, recomb.end, closed='both')
    #reporttest_range = pd.Interval(regions.start, regions.end, closed='both')
    print(ref_interval)
    print(recomb_interval)
    recomb_interval.overlaps(ref_interval)
    #print(iix)


    
    

    refgbk = '/data/qguo/projects/baoman/single/single_all/ref/outgroup_annotated/outgroup_annotated.gbk'
    refgbk = SeqIO.read(refgbk, 'genbank')
    region = refgbk[174:2813]
    print(region.features)
    for feature in region.features:
        print(feature.qualifiers)
    """