import sys, os
import numpy as np
import pandas as pd
from tqdm import tqdm
from scipy import stats

def process_dnds_df(df):
    df = df.drop([0, 2, 3], 1)
    df.columns = ['Gene1', 'Gene2', 't', 'S', 'N', 'dN/dS', 'dN', 'dS']
    df['Gene1'] = df['Gene1'].str.strip('(').str.strip(')')
    df['Gene2'] = df['Gene2'].str.strip('(').str.strip(')')
    df['t'] = df['t'].str.split('=', 2, expand = True)[1].astype('float')
    df['S'] = df['S'].str.split('=', 2, expand=True)[1].astype('float')
    df['N'] = df['N'].str.split('=', 2, expand=True)[1].astype('float')
    df['dN/dS'] = df['dN/dS'].str.split('=', 2, expand=True)[1].astype('float')
    df['dN'] = df['dN'].str.split('=', 2, expand=True)[1].astype('float')
    df['dS'] = df['dS'].str.split('=', 2, expand=True)[1].astype('float')
    df = df[(df['dS'] <= 2) & (df['dS'] >= 0.01)]
    return df


def sample_seq_relationship(df, colnam):
    outdf = pd.DataFrame({'sample':[colnam] * len(df), 'Seq':df[colnam]})
    outdf = outdf.drop('Seq', axis=1).join(outdf['Seq'].str.split('\t', expand=True).stack().reset_index(level=1, drop=True).rename('Seq'))
    outdf = outdf.dropna()
    return outdf

if __name__=='__main__':
    dndsdir = sys.argv[1]
    os.chdir(dndsdir)

    #print(sample_seq)

    dnds_list = [i for i in os.listdir('res/') if os.path.splitext(i)[-1] == '.dnds']
    for i in tqdm(range(len(dnds_list))):
    #for i in range(0,5):
        f = dnds_list[i]
        os.system("sed 's/\s\+/ /g' " + 'res/' + f +' > selection/' + f)
        os.system("sed -i 's/= /=/g' " + 'selection/' + f)
        os.system("sed -i 's/ =/=/g' " + 'selection/' + f)
        try:
            data = pd.read_csv('selection/' + f, sep = ' ', header=None)
            data = process_dnds_df(data)
            # positive selection
            data_pos = data[data['dN/dS'] > 1]
            if len(data_pos) > 0:
                data_pos.to_csv('selection/pos/' + f, sep = '\t', index = False)
                #break
        except:
            print(f)
