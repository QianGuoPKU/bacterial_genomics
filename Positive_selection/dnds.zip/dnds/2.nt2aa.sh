dndsdir=$1
cd $dndsdir
ls genes/*.fasta > files
cut -d "/" -f2 files >samples
for name in `cat samples`
do
nt2aa genes/$name 
mv genes/$name'.csqa' proteins/$name
done



