#$1: dnds dir;
cd $1
cut -d "." -f1 samples >gene.list5
for name in `cat gene.list5`
do
echo $name
/data2/qguo/software/clustalo-1.2.4-Ubuntu-x86_64 -force -i proteins/$name.fasta -o res/$name.aln --threads 40 --outfmt=clu
/data2/qguo/software/pal2nal.v14/pal2nal.pl res/$name.aln genes/$name.fasta -output paml -nogap >res/$name.codon
cp /data/qguo/projects/baoman/single/code/dnds/test.cnt res/$name.cnt
sed -i '1,2d' res/$name.cnt
sed -i "1i\\	seqfile = res/${name}.codon"  res/$name.cnt
sed -i "1a\\	outfile = res/${name}.codeml" res/$name.cnt
codeml res/$name.cnt
#grep "dN/dS="  $3/$name.codeml | awk -v num="${name}" '{print num"\t"$0}' >> $3/$name.dnds
grep "dN/dS="  res/$name.codeml >res/$name'.1' 
grep "\.\.\." res/$name.codeml >res/$name'.2'
paste -d "\t" res/$name'.2' res/$name'.1' >res/$name.dnds
rm -f $name'.1' $name'.2'
done


