import sys, os
from Bio import SeqIO
import numpy as np
import pandas as pd
from tqdm import tqdm
from scipy import stats

if __name__=='__main__':
    roary_dir = sys.argv[1]
    outdir = sys.argv[2]
    gene_abs_pres = pd.read_csv(roary_dir + '/gene_presence_absence.csv')
    genes = gene_abs_pres[gene_abs_pres['No. sequences'] > 1]['Gene'].tolist()
    uniq_seq_nums = []
    used_uniq_seq_nums = []
    for i in tqdm(range(len(genes))):
    #for i in range(len(genes)):
        gene = genes[i]
        gene = gene.replace('-', '_').replace("'", '_').replace('(', '_').replace(')', '_')
        infasta = roary_dir + '/pan_genome_sequences/' + gene + '.fa.aln'
        seq_dict = {}
        seq_lens = []
        for record in SeqIO.parse(infasta, 'fasta'):
            id = record.id
            seq = str(record.seq)
            seq = seq.replace('-', '').upper()
            if len(seq_dict) == 0:
                seq_dict[seq] = id
                seq_lens.append(len(seq))
            else:
                if seq in seq_dict.keys():
                    seq_dict[seq] = seq_dict[seq] + ',' + id
                else:
                    seq_dict[seq] = id
                    seq_lens.append(len(seq))
        uniq_seq_num = len(seq_dict)
        uniq_seq_nums.append(uniq_seq_num)
        if uniq_seq_num > 1:
            seq_dict_copy = seq_dict.copy()
            for k in seq_dict_copy.keys():
                if len(k) < np.max(seq_lens)*0.8:
                    del seq_dict[k]
            used_uniq_seq_num = len(seq_dict)
            if used_uniq_seq_num > 1:
                outfasta = open(outdir + '/genes/' + gene + '.fasta', 'w')
                outheader = open(outdir + '/headers/' + gene + '.header', 'w')
                for j in range(len(seq_dict)):
                    outhead = list(seq_dict.values())[j]
                    outseq = list(seq_dict.keys())[j]
                    outfasta.write('>' + gene + '#' + str(j) + '\n' + outseq + '\n')
                    outheader.write(gene + '#' + str(j) + '\t' + outhead + '\n')
        used_uniq_seq_num = len(seq_dict)
        used_uniq_seq_nums.append(used_uniq_seq_num)

    outdf = pd.DataFrame({'Gene':genes, 'uniq_seq_num':uniq_seq_nums, 'used_uniq_seq_num':used_uniq_seq_nums})
    outdf = pd.merge(gene_abs_pres, outdf, on = 'Gene', how = 'left')
    outdf.to_csv(outdir + '/gene_presence_absence.csv', index=False)

