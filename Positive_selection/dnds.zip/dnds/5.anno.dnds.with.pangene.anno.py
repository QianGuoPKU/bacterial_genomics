import sys, os
import numpy as np
import pandas as pd
from tqdm import tqdm
from scipy import stats

"""
 1327  cat *dnds >dnds.all
 1328  less -S dnds.all 
 1329  sed -i '/Gene1/d' dnds.all 
 1330  less -S dnds.all 
 1331  head -n 1 aac.dnds >header
 1332  cat header dnds.all >dnds.all1
 1333  mv dnds.all1 dnds.all
"""

if __name__=='__main__':

    indir = sys.argv[1]
    annofile = sys.argv[2]

    os.chdir(indir)

    dnds = pd.read_csv('dnds.all', sep = '\t')
    anno = pd.read_csv(annofile, sep = '\t')

    dnds['Gene'] = dnds['Gene1'].str.split('#', expand = True)[0]
    out = pd.merge(dnds, anno, on = 'Gene', how='left')
    out.to_csv('dnds.all.anno.txt', sep = '\t', index=False)

    out = out.drop_duplicates(subset=['Gene'], keep='first')
    out.to_csv('dnds.all.anno.uniq.txt', sep='\t', index=False)
