import sys, os
import numpy as np
import pandas as pd
from tqdm import tqdm
from scipy import stats

def process_dnds_df(df):
    df = df.drop([0, 2, 3], 1)
    df.columns = ['Gene1', 'Gene2', 't', 'S', 'N', 'dN/dS', 'dN', 'dS']
    df['Gene1'] = df['Gene1'].str.strip('(').str.strip(')')
    df['Gene2'] = df['Gene2'].str.strip('(').str.strip(')')
    df['t'] = df['t'].str.split('=', 2, expand = True)[1].astype('float')
    df['S'] = df['S'].str.split('=', 2, expand=True)[1].astype('float')
    df['N'] = df['N'].str.split('=', 2, expand=True)[1].astype('float')
    df['dN/dS'] = df['dN/dS'].str.split('=', 2, expand=True)[1].astype('float')
    df['dN'] = df['dN'].str.split('=', 2, expand=True)[1].astype('float')
    df['dS'] = df['dS'].str.split('=', 2, expand=True)[1].astype('float')
    df = df[(df['dS'] <= 2) & (df['dS'] >= 0.01)]
    return df


def sample_seq_relationship(df, colnam):
    outdf = pd.DataFrame({'sample':[colnam] * len(df), 'Seq':df[colnam]})
    outdf = outdf.drop('Seq', axis=1).join(outdf['Seq'].str.split('\t', expand=True).stack().reset_index(level=1, drop=True).rename('Seq'))
    outdf = outdf.dropna()
    return outdf

if __name__=='__main__':
    dndsdir = sys.argv[1]
    os.chdir(dndsdir)

    # step1: create the sample & seq relationship dataframe and output it
    """
    gene_pre_abs = pd.read_csv('gene_presence_absence.csv', header=0)
    # build the sample & seq relationships
    sample_seq_df = pd.DataFrame()
    for colnam in gene_pre_abs.columns.tolist()[14:-2]:
        df = sample_seq_relationship(gene_pre_abs, colnam)
        sample_seq_df = pd.concat([sample_seq_df, df])
    print(sample_seq_df)
    sample_seq_df.to_csv('sample_seq.txt', sep = '\t', index=False)
    """

    sample_seq = pd.read_csv('sample_seq.txt', sep='\t', header=0)
    # step2: add the clone and lineage info to the sample_seq df
    metadata = pd.read_csv('/data/qguo/projects/baoman/single/single_all/metadata/metadata_20221024.txt',
                           header=0, sep = '\t', usecols=['sample', 'sublineage', 'clone', 'Oxford.ST'])
    metadata['clone'] = metadata['clone'].fillna(0)
    metadata['clone'] = metadata['clone'].astype('int')
    sample_seq = pd.merge(sample_seq, metadata, on = 'sample', how = 'left')

    #print(sample_seq)

    dnds_list = [i for i in os.listdir('selection/pos/') if os.path.splitext(i)[-1] == '.dnds']
    for i in tqdm(range(len(dnds_list))):
        f = dnds_list[i]
        data_pos = pd.read_csv('selection/pos/' + f, sep = '\t')


        # add seq info
        seq_header = pd.read_csv('headers/' + f.replace('dnds', 'header'), sep = '\t', header=None)
        seq_header.columns = ['Gene', 'Seq']
        data_pos = pd.merge(data_pos, seq_header, left_on='Gene1', right_on='Gene', how='left')
        data_pos = pd.merge(data_pos, seq_header, left_on='Gene2', right_on='Gene', how='left')
        data_pos = data_pos.drop(['Gene_x', 'Gene_y'], 1)
        data_pos = data_pos.rename(columns={"Seq_x": "Seq1", "Seq_y": "Seq2"})
        data_pos = data_pos.drop('Seq1', axis=1).join(data_pos['Seq1'].str.split(',', expand=True).stack().reset_index(level=1, drop=True).rename('Seq1'))
        data_pos = data_pos.drop('Seq2', axis=1).join(
            data_pos['Seq2'].str.split(',', expand=True).stack().reset_index(level=1, drop=True).rename('Seq2'))

        # add sample info
        data_pos = pd.merge(data_pos, sample_seq, left_on='Seq1', right_on='Seq', how='left')
        data_pos = data_pos.drop(['Seq'], 1)
        data_pos = data_pos.rename(columns={"sample": "sample1", "sublineage": "sublineage1", "clone":'clone1', "Oxford.ST":"ST1"})
        data_pos = pd.merge(data_pos, sample_seq, left_on='Seq2', right_on='Seq', how='left')
        data_pos = data_pos.drop(['Seq'], 1)
        data_pos = data_pos.rename(columns={"sample": "sample2", "sublineage": "sublineage2", "clone": 'clone2', "Oxford.ST":"ST2"})

        # output sample unit
        data_pos.to_csv('selection/pos/' + f + '.sample', sep = '\t', index=False)

        # output clone unit
        data_pos_clone = data_pos.copy()
        data_pos_clone = data_pos_clone.drop(['Seq1', 'Seq2', 'sample1', 'sample2', 'sublineage1', 'sublineage2'],1)
        data_pos_clone = data_pos_clone.drop_duplicates()
        if (f == 'srrA.dnds'):
            print(data_pos_clone)
        data_pos_clone = data_pos_clone[(data_pos_clone['clone1'] != 0) & (data_pos_clone['clone2'] != 0)]
        data_pos_clone.to_csv('selection/pos/' + f + '.clone', sep = '\t', index=False)
        data_pos_clone = data_pos_clone[data_pos_clone['clone1'] == data_pos_clone['clone2']]
        data_pos_clone.to_csv('selection/pos/' + f + '.clone.same', sep='\t', index=False)
        #print(data_pos_clone)

        # output lineage unit
        data_pos_lineage = data_pos.copy()
        data_pos_lineage = data_pos_lineage.drop(['Seq1', 'Seq2', 'sample1', 'sample2', 'clone1', 'clone2'], 1)
        data_pos_lineage = data_pos_lineage.drop_duplicates()
        #data_pos_lineage = data_pos_lineage.dropna(axis=0, how='any')
        data_pos_lineage.to_csv('selection/pos/' + f + '.sublineage', sep='\t', index=False)
        data_pos_lineage = data_pos_lineage[data_pos_lineage['sublineage1'] == data_pos_lineage['sublineage2']]
        data_pos_lineage.to_csv('selection/pos/' + f + '.sublineage.same', sep='\t', index=False)
        #print(data_pos_lineage)
            #break
