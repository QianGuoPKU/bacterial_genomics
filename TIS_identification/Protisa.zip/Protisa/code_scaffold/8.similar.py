import sys, os
import numpy as np
import pandas as pd
from tqdm import tqdm

def comp_signals(df, name):
    # df is the dataframe combining environmental annotation and signal information
    # redundant_cluster_6080
    clusters = list(np.unique(np.nan_to_num(df[name].tolist())))
    if 0 in clusters:
        del clusters[clusters.index(0)]
    signals_notes = []
    signals_pvals = []
    signals_qvals = []
    for i in range(len(clusters)):
        subset = df[df[name] == clusters[i]]
        signals = subset['Translation Signal Sequence'].tolist()
        sequences = subset['sequence'].tolist()
        signals = list(np.nan_to_num(signals))
        note = ""
        if 'nan' in signals:
            ind = signals.index('nan')
            sequence = sequences[ind]
            note = 'No TIS: ' + sequence
            del signals[ind]
        else:
            if 0 in signals:
                n_zero = np.count_nonzero(np.array(signals))
                if n_zero:
                    ind = signals.index(0)
                    sequence = sequences[ind]
                    note = 'No TIS: ' + sequence
                    del signals[ind]
                else:
                    note = 'No TIS: all gene'
                    signals = []
            #else:
                #note = ''
        if len(signals) > 1:
            #print(signals)
            pvals = []
            qvals = []
            for j in range(len(signals) - 1):
                signal1 = signals[j]
                os.system('~/software/meme-5.4.1/scripts/iupac2meme ' + signal1 + ' >tmp1')
                for k in range(j + 1, len(signals)):
                    signal2 = signals[k]
                    if signal1 == signal2:
                        pval = 0
                        qval = 0
                    else:
                        os.system('~/software/meme-5.4.1/scripts/iupac2meme ' + signal2 + ' >tmp2')
                        os.system(
                            '~/software/meme-5.4.1/bin/tomtom -no-ssc -verbosity 1 -min-overlap 5 -mi 1 -dist pearson -evalue -thresh 10.0 -time 300 -oc out tmp1 tmp2')
                        tomtom = pd.read_csv("out/tomtom.tsv", sep="\t", comment='#', header=0)
                        pval = tomtom['p-value'].tolist()[0]
                        qval = tomtom['q-value'].tolist()[0]
                    pvals.append(pval)
                    qvals.append(qval)
        else:
            pvals = [1]
            qvals = [1]
        signals_notes.append(note)
        signals_pvals.append(','.join([str(i) for i in pvals]))
        signals_qvals.append(','.join([str(i) for i in qvals]))
    outdf = pd.DataFrame({'cluster':clusters, 'p':signals_pvals, 'q':signals_qvals, 'note':signals_notes})

    return outdf




# /data2/qguo/software/meme-5.4.1/scripts/iupac2meme
if __name__ == '__main__':
    # step1: combine the signal table with the environmental annotation table
    # step2: select the redundant cluster subset
    # step3: compare the signal for each cluster in each sample; note the no signal sequences

    samplelistfile = sys.argv[1]
    clustertabledir = sys.argv[2]
    signaltabledir = sys.argv[3]
    outdir = sys.argv[4]
    os.chdir(outdir)

    samples = pd.read_csv(samplelistfile, header=None, sep='\t')
    samples.columns = ['sample']
    samples = samples['sample'].tolist()

    for sample in samples:
        print(sample)
        clustertablefile = clustertabledir + '/' + sample + '_table.txt'
        signaltablefile = signaltabledir + '/' + sample + '.tis.rec.dat'
        outtablefile = 'table/' + sample + '_table.txt'

        if os.path.exists(outtablefile):
            continue
        else:
            try:
                clustertable = pd.read_csv(clustertablefile, sep = '\t', header=0)
                signaltable = pd.read_csv(signaltablefile, sep = '\t', header = 0)
                signaltable['sequence'] = signaltable['Locus'].str.replace('Prokka_', '')
                signaltable = signaltable.drop(signaltable.columns[[0,1,2,3,4,5,6]], axis=1)
                signaltable = signaltable.drop(['Feature'], 1)
                outtable = pd.merge(clustertable, signaltable, on='sequence', how='left')

                print('6080')
                df = comp_signals(outtable, 'redundant_cluster_6080')
                df.columns = df.columns + '_6080'
                outtable = pd.merge(outtable, df, left_on='redundant_cluster_6080', right_on=list(df.columns)[0], how='left')

                print('8080')
                df = comp_signals(outtable, 'redundant_cluster_8080')
                df.columns = df.columns + '_8080'
                outtable = pd.merge(outtable, df, left_on='redundant_cluster_8080', right_on=list(df.columns)[0], how='left')

                print('95100')
                df = comp_signals(outtable, 'redundant_cluster_95100')
                df.columns = df.columns + '_95100'
                outtable = pd.merge(outtable, df, left_on='redundant_cluster_95100', right_on=list(df.columns)[0], how='left')

                outtable.to_csv(outtablefile, sep='\t', index=False)
                print('\t')
            except:
                print('Wrong...')