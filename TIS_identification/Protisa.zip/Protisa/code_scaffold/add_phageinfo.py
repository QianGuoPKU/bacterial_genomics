import sys, os
import numpy as np
import pandas as pd
from tqdm import tqdm


# /data2/qguo/software/meme-5.4.1/scripts/iupac2meme
if __name__ == '__main__':
    # step1: combine the signal table with the environmental annotation table
    # step2: select the redundant cluster subset
    # step3: compare the signal for each cluster in each sample; note the no signal sequences

    samplelistfile = sys.argv[1]
    clustertabledir = sys.argv[2]
    signaltabledir = sys.argv[3]
    outdir = sys.argv[4]
    #os.chdir(outdir)

    samples = pd.read_csv(samplelistfile, header=None, sep='\t')
    samples.columns = ['sample']
    samples = samples['sample'].tolist()

    for sample in samples:
        print(sample)
        file = sample + '_table.txt'
        clustertablefile = clustertabledir + '/' + file
        signaltablefile = signaltabledir + '/' + file
        outtablefile = outdir + '/' + file

        if os.path.exists(outtablefile):
            continue
        else:
            try:
                clustertable = pd.read_csv(clustertablefile, sep = '\t', header=0)
                clustertable = clustertable[['sequence', 'phaster']]
                signaltable = pd.read_csv(signaltablefile, sep = '\t', header = 0)
                outtable = pd.merge(signaltable, clustertable, on='sequence', how='left')
                outtable.to_csv(outtablefile, sep = '\t', index=False)
            except:
                print('Wrong...')