#pragma once
#ifndef ESTIMATE_H
#define ESTIMATE_H

#include "common.h"

Str estimate(Str Out, Str GenoID, rec red);

#endif