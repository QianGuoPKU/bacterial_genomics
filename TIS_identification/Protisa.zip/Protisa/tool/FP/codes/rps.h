#pragma once
#ifndef RPS_H
#define RPS_H

#include "common.h"

Str rps(Str Out, Str GenoID, rec red, Ma_Str_X tax, Ma_Str_Str cog);

#endif