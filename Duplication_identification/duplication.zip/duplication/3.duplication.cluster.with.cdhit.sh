cd-hit -i all_proteins.faa -o db8080 -c 0.8 -n 5 -d 0 -M 150000 -T 52 -aS 0.8 -aL 0.8 -g 1




