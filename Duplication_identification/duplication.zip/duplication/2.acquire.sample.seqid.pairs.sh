outfile=$3
for name in `cat $1`
do
echo $name 
head -n 1 $2/$name/$name'.faa' | cut -d ">" -f2| awk -v FS="_" -v OFS="\t" -v sample=${name} -v outfile=${outfile} '{system("echo -e "$1" "sample"  >> "outfile" ")}'
done





