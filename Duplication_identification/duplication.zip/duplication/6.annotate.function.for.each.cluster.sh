# $1: the dir for query seq; $2: the prefix of query seq
cd $1
#sed 's/ /#/' *.ffn >$2'.ffn'
#sed 's/ /#/' *.faa >$2'.faa'
#sed 's/ /#/' *.faa >$2'.fna'
blastn -task blastn -db /data2/qguo/reference_databases/isfinder/blastdb/isfinder -query $2'.ffn' -out isfinder.txt -max_target_seqs 1 -evalue 1e-3 -outfmt 6 -num_threads 40 -perc_identity 80
diamond blastp --db  /data2/qguo/reference_databases/phage/phaster/phaster.dmnd --ungapped-score 95 --min-score 95 --query $2'.faa' --out phaster.txt -p 40 --query-cover 80 --subject-cover 80 --outfmt 6  --max-target-seqs 1 --evalue 1e-3  --id 80
diamond blastp --db  /data2/qguo/reference_databases/cog/cog.dmnd --ungapped-score 95 --min-score 95 --query $2'.faa' --out cog.txt  -p 40 --query-cover 80 --subject-cover 80 --outfmt 6  --max-target-seqs 1 --evalue 1e-3  --id 80
diamond blastp --db  /data2/qguo/reference_databases/vfdb/vfdb_setb.dmnd --ungapped-score 95 --min-score 95 --query $2'.faa' --out vfdb.txt -p 40 --query-cover 80 --subject-cover 80 --outfmt 6  --max-target-seqs 1 --evalue 1e-3  --id 80
/data2/qguo/anaconda3/envs/abricate_qg/bin/abricate --db card --threads 40 $2'.ffn' > card.txt
diamond blastp --db /data2/qguo/reference_databases/BacMet/bacmet_exp.dmnd --ungapped-score 95 --min-score 95 --query $2'.faa' --out bacmet_exp.txt -p 40 --query-cover 80 --subject-cover 80 --outfmt 6  --max-target-seqs 1 --evalue 1e-3  --id 80
diamond blastp --db /data2/qguo/reference_databases/BacMet/bacmet_pred.dmnd --ungapped-score 95 --min-score 95 --query $2'.faa' --out bacmet_pred.txt -p 40 --query-cover 80 --subject-cover 80 --outfmt 6  --max-target-seqs 1 --evalue 1e-3  --id 80
python /data/qguo/projects/tnDB/programs/Tnfinder.py -i $2'.fna' -o $2'_tn' -p /data/qguo/projects/tnDB/programs/database -d Tnseq.latest