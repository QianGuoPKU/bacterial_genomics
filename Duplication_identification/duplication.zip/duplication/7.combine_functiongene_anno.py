import sys, os
import numpy as np
import pandas as pd
from tqdm import tqdm

def combine_rows(df):
    return ','.join(df.values)

if __name__ == '__main__':
    indir = sys.argv[1] # /data/qguo/projects/baoman/single/single_icu/annotation_on_scaffolds/roary/pangenome
    os.chdir(indir)

    cogfile = 'cog.txt'
    cardfile = 'card.txt'
    vfdbfile = 'vfdb.txt'
    isfinderfile = 'isfinder.txt'
    phasterfile = 'phaster.txt'
    bacmet_exp_file = 'bacmet_exp.txt'
    bacmet_pred_file = 'bacmet_pred.txt'

    os.system("grep '>' *.faa | cut -d '>' -f2 > list")
    os.system('sed -i "s/ /#/g" list')

    pre_abs = pd.read_csv('list', sep='\t', header=None)
    pre_abs.columns = ['prokka']
    pre_abs['Gene'] = pre_abs['prokka'].str.split('#', 1, expand=True)[0]

    cog_db = pd.read_csv('/data2/qguo/reference_databases/cog/gi_functionclass.txt', sep='\t', header=0)
    cog_db['GI'] = cog_db['GI'].astype('str')
    cog = pd.read_csv(cogfile, sep = '\t')
    cog = pd.read_csv(cogfile, sep='\t', header=0, usecols=[0, 1])
    cog.columns = ['Gene', 'cog']
    #cog['Gene'] = cog['Gene'].str.split('#', expand=True)[1]
    cog['GI'] = cog['cog'].str.split('\|', expand=True)[1]
    cog['COG_name'] = cog['cog'].str.split('\|', expand=True)[4].str.replace('#', ' ').str.strip()
    cog = cog.drop(['cog'], 1)
    cog = pd.merge(cog, cog_db, on='GI', how='left')
    pre_abs = pd.merge(pre_abs, cog, on = 'Gene', how = 'left')

    card = pd.read_csv(cardfile, sep='\t', header=0, usecols=[1, 5, 14])
    card.columns = ['Gene', 'card', 'card_function']
    #card['Gene'] = card['Gene'].str.split('#', expand=True)[1]
    card['card'] = card['card'] + '#' + card['card_function']
    card = card.drop(['card_function'], 1)
    card = card.groupby(['Gene'])['card'].apply(combine_rows).reset_index()
    pre_abs = pd.merge(pre_abs, card, on='Gene', how='left')

    vfdb = pd.read_csv(vfdbfile, sep='\t', header=None, usecols=[0, 1])
    vfdb.columns = ['Gene', 'vfdb']
    #vfdb['Gene'] = vfdb['Gene'].str.split('#', expand=True)[1]
    vfdb = vfdb.groupby(['Gene'])['vfdb'].apply(combine_rows).reset_index()
    pre_abs = pd.merge(pre_abs, vfdb, on='Gene', how='left')

    isfinder = pd.read_csv(isfinderfile, sep='\t', header=None, usecols=[0, 1])
    isfinder.columns = ['Gene', 'is']
    #isfinder['Gene'] = isfinder['Gene'].str.split('#', expand=True)[1]
    isfinder = isfinder.groupby(['Gene'])['is'].apply(combine_rows).reset_index()
    pre_abs = pd.merge(pre_abs, isfinder, on='Gene', how='left')

    phaster = pd.read_csv(phasterfile, sep='\t', header=None, usecols=[0, 1])
    phaster.columns = ['Gene', 'phaster']
    #phaster['Gene'] = phaster['Gene'].str.split('#', expand=True)[1]
    phaster = phaster.groupby(['Gene'])['phaster'].apply(combine_rows).reset_index()
    pre_abs = pd.merge(pre_abs, phaster, on='Gene', how='left')

    bacmet_exp = pd.read_csv(bacmet_exp_file, sep='\t', header=None, usecols=[0, 1])
    bacmet_exp.columns = ['Gene', 'bacmet_exp']
    # vfdb['Gene'] = vfdb['Gene'].str.split('#', expand=True)[1]
    bacmet_exp = bacmet_exp.groupby(['Gene'])['bacmet_exp'].apply(combine_rows).reset_index()
    pre_abs = pd.merge(pre_abs, bacmet_exp, on='Gene', how='left')

    bacmet_pred = pd.read_csv(bacmet_pred_file, sep='\t', header=None, usecols=[0, 1])
    bacmet_pred.columns = ['Gene', 'bacmet_pred']
    # vfdb['Gene'] = vfdb['Gene'].str.split('#', expand=True)[1]
    bacmet_pred = bacmet_pred.groupby(['Gene'])['bacmet_pred'].apply(combine_rows).reset_index()
    pre_abs = pd.merge(pre_abs, bacmet_pred, on='Gene', how='left')

    pre_abs.to_csv('cluster_function.txt', sep = '\t', index = False)