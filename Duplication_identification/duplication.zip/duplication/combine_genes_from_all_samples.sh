for name in `cat $1`
do
echo $name
cat $2/$name/$name'.ffn' >> $3/all_genes.ffn
done





