import sys, os
from Bio import SeqIO
import numpy as np
import pandas as pd
from tqdm import tqdm
from scipy import stats

if __name__=='__main__':
    samplelist = sys.argv[1]
    prokkadir = sys.argv[2]
    wkdir = sys.argv[3]


    os.system('bash /data/qguo/projects/baoman/single/single_all/code/duplication/combine_genes_from_all_samples.sh ' + samplelist + ' ' + prokkadir + ' ' + wkdir)
    os.chdir(wkdir)
    wantedseqs = []
    for rec in SeqIO.parse('db8080', 'fasta'):
        wantedseqs.append(str(rec.id))
    

    with open('db8080_genes.ffn', 'w') as fout:
        for rec in SeqIO.parse('all_genes.ffn', 'fasta'):
            if str(rec.id) in wantedseqs:
                fout.write('>' + str(rec.id) + '\n')
                fout.write(str(rec.seq) + '\n')
