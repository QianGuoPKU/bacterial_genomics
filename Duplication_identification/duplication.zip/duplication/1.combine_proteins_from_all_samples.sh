for name in `cat $1`
do
echo $name
cat $2/$name/$name'.faa' >> $3/all_proteins.faa
done





