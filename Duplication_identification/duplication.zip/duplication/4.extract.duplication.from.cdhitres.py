import pandas as pd
import numpy as np
import sys, os

if __name__ == '__main__':
    infile = sys.argv[1] #
    outfile = sys.argv[2]

    sample_seq = pd.read_csv('/data/qguo/projects/baoman/single/single_all/duplication/cdhit-res/sample_seqid', header=None, sep = ' ')
    sample_seq.columns = ['seqid', 'sample']
    sample_seq = sample_seq[["seqid", "sample"]].set_index("seqid").to_dict(orient='dict')["sample"]

    #"""
    repre_seqs = {}
    seqids = {}
    seqsamples = {}
    with open(infile, 'r') as fin:
        for l in fin.readlines():
            seqflag = 0
            if l.startswith('>'):
                cluster = l.strip('>').strip('\n').split(" ")[1]
            else:
                seqid = l.split('>')[1].split('.')[0]
                sampleid = seqid.split('_')[0]
                if len(seqids) == 0:
                    seqids[cluster] = seqid
                    seqsamples[cluster] = sample_seq[sampleid]
                else:
                    if cluster in seqids.keys():
                        seqids[cluster] = seqids[cluster] + ',' + seqid
                        seqsamples[cluster] = seqsamples[cluster] + ',' + sample_seq[sampleid]
                    else:
                        seqids[cluster] = seqid
                        seqsamples[cluster] = sample_seq[sampleid]
                if "*" in l:
                    repre_seqs[cluster] = seqid

    outdf = pd.DataFrame({'Cluster':list(seqids.keys()), 'represent_seqid':list(repre_seqs.values()), 'seqid':list(seqids.values()), 'sample':list(seqsamples.values())})
    outdf.to_csv(outfile, sep = '\t', index=False)
    #"""



