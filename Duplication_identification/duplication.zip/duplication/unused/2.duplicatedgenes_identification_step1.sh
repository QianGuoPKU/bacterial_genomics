# blastclust parameters: -a cpus; -S bit score/coverage length (identity), 0-100 int value; -L coverage 0-1 float value
# set 80: coverage-60, identity-80; set 100: coverage-95, identity-100
for name in `cat $1`
do
echo $name
/data2/qguo/software/blast-2.2.24/bin/blastclust -a 40 -i $2/$name/$name'.faa' -o $3/$name'_cluster_'$4'_'$5'_complete.csv' -e F -S $4 -L $5 -b T
done




